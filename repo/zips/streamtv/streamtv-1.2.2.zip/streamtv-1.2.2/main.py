import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Free sample videos are provided by www.vidsplay.com
# Here we use a fixed set of properties simply for demonstrating purposes
# In a "real life" plugin you will need to get info and links to video files/streams
# from some web-site or online service.
VIDEOS = {'Derniers Ajouts': [{'name': 'Le Samaritain (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/iX69aMEMO0W22bAX11lGP8DeTkr.jpg',
						'video': 'https://toma627.tomacloud.com/files/kC6m0D9P1FD92ZWT0oVfoyYDo3OcyYOSBVe.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Beckenrand Sheriff (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/knYcXhKLLIP6GtyuvcZxLp59P8a.jpg',
						'video': 'https://toma400.tomacloud.com/files/RFGVwef8BI2ykom0Jur1XjTcpu0Eql8h0Pd.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Le Royaume de Terracotta (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/xbsgNAg021mKIbj2mBvB3LzvYVP.jpg',
						'video': 'https://toma761.tomacloud.com/files/3pMRKvcyBzqwiEsX27fvVS7xyGt7dYihn58.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Les Nouvelles Aventures de Gulliver (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/76ZSoIbdCQuPo2dW6Na7XybL1ax.jpg',
						'video': 'https://toma126.tomacloud.com/files/lNx9lMvw5Wt4Pr7AX9jEIHfbUgeTNsI8gfh.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'The Aviary (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/u6HUQcOQsgkFFO8xCITfxQz6ivc.jpg',
						'video': 'https://toma877.tomacloud.com/files/s26fxPQyCUMBmPUyJ2xoL53HLtRmaEWCG2S.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Sword Master (2016) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/sCsFOWDTETklLlVj34msCn0S6JP.jpg',
						'video': 'https://toma107.tomacloud.com/files/jvbX0EfsQ9hyr4hOjgK8lnfdyKrGOd38Ie5.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Petite fleur (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/lMO0n5CAMRftZGebjTCXmufuJiZ.jpg',
						'video': 'https://toma187.tomacloud.com/files/hUpkg5qFzqpaALwMKrB7PmT7CMKTSG5aBuu.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Beast (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/iRV0IB5xQeOymuGGUBarTecQVAl.jpg',
						'video': 'https://toma794.tomacloud.com/files/yOEW17exSOkDuItVWrRaS33tddRed02LPGI.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'End of the Road (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/tLFIMuPWJHlTJ6TN8HCOiSD6SdA.jpg',
						'video': 'https://toma126.tomacloud.com/files/YqLYobzgHwB2P8f1XuicH7hEdTUBqoFpOqn.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'The Captain (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/jG82eg6xnG95XuR6Tqn6GjXytQI.jpg',
						'video': 'https://toma51.tomacloud.com/files/AxN9QeZiL37OGgI6E4dEbkTCzErsQZVrxIA.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Trois mille ans à t\'attendre (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/eCYaYduejXz9SIkLsKkHESU1sWq.jpg',
						'video': 'https://toma804.tomacloud.com/files/EFXD49vt1LOnRNwJ13XLuh1dgrfeHa5lQ2Z.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Don Juan (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/gsy1V0FRqa9yfgbc8PuGHZE1kL1.jpg',
						'video': 'https://toma126.tomacloud.com/files/Tqrf1T7db2sMYgJqz1ncd98KDTF1w9PqAgF.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Pinocchio (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/h32gl4a3QxQWNiNaR4Fc1uvLBkV.jpg',
						'video': 'https://toma655.tomacloud.com/files/yf2TccsNwFrqYAcY9SMTVIipkzvi8r7HHaB.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Thor : Love And Thunder (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/kSMarEm3ESOOr11dzsep2RZ1ClD.jpg',
						'video': 'https://toma577.tomacloud.com/files/cj9AuFqMDZkRU14OvIlKjR9VhcaXOFb0YkA.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Thor : Ragnarok (2017) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/mAA8RXkgF87jSWWMSf6hgLl73mk.jpg',
						'video': 'https://toma50.tomacloud.com/files/sHfA581t2Nu2uT9eoocOsIzaNapvst3Vaiw.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Thor : Le Monde des ténèbres (2013) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/eAIGX0nlwlb5sMb4uDRGNFqMyG9.jpg',
						'video': 'https://toma57.tomacloud.com/files/fJ7JTjFTBSm4ae55GYoJ1g2wM1TsKGr0pyJ.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Thor (2011) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/q8pF6s9b9veTQvxTqMDIQf9nJKi.jpg',
						'video': 'https://toma468.tomacloud.com/files/h66mjYWzFTTdHtFrM2Oq7Xxc4aEDIwRZCYm.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Sous emprise (2022) ',
						'thumb': 'https://i.imgur.com/AF2sqtm.png',
						'video': 'https://toma794.tomacloud.com/files/Po3QQhUWIUCkIMtZXvnsUqEJeT5dRzgHXjx.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Alice : De l\'esclavage à la liberté (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/4VvXHIWw6yie5Y4G41Vnrh2n0XL.jpg',
						'video': 'https://toma288.tomacloud.com/files/vhaqKEEovgnJ6tzhGx5m2XqbCX51za35sew.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Train de guerre : le corridor de l\'espoir (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/3quDnxahqLnQWYE67xsmVIvDN7D.jpg',
						'video': 'https://toma877.tomacloud.com/files/3dOjb1HkyjgljynzMeLCDgNOyeJ95fi9s6t.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'That\'s Amor (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/iyYibVfi8q0zwsX1evl7mxTZJp1.jpg',
						'video': 'https://toma664.tomacloud.com/files/Q1foKxgu3p0cH6jEM6QCa40iFdg9n5Od63C.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'The Ledge (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/dHKfsdNcEPw7YIWFPIhqiuWrSAb.jpg',
						'video': 'https://toma765.tomacloud.com/files/M25rruyAxdUI7cMNt6pXROj4gxSEyp0ks6M.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Inexorable (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/iiclsw6zgRJz5D5Cc6sn4Cs9GQo.jpg',
						'video': 'https://toma187.tomacloud.com/files/vDluDF5degeDLeQOzVN0TCEd6qhaeyQKcce.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Loving Adults (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/mNSqObjKszcxr55buQafQF9ARiC.jpg',
						'video': 'https://toma187.tomacloud.com/files/NeTKFbhwmi4mMXTrEKk7jeiC6aE1SYxGdqq.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Seoul Vibe (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/ffX0TL3uKerLXACkuZGWhAPMbAq.jpg',
						'video': 'https://toma107.tomacloud.com/files/6mVWJafUBsbsHhOl0AsPZC9qJyjyVjU1GQX.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Ogre (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/3QxtIzY8vRI4FV2hHUNrN9JifYf.jpg',
						'video': 'https://toma57.tomacloud.com/files/z5O9VRIGFvAkFjXMsWEuDUlicj61vCy4Hne.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Animals (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/o4jzqLiDQ6gfXZmCk4TvLpDpWwU.jpg',
						'video': 'https://toma735.tomacloud.com/files/8bYEubCJUtyh8NwEjr1Fshpx0dEvuRED2Dh.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Once in the Desert (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/wkRVulJ1BxlA2KtJSsGjpYARc0f.jpg',
						'video': 'https://toma664.tomacloud.com/files/rQtL1bohGAA7SNerESlvD41i5sm7Iue9kIU.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Crawlspace (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/qEu6qI5sVoIe10gD1BQBqxcNIW2.jpg',
						'video': 'https://toma288.tomacloud.com/files/sEsIMBy8xul9Ha3v8vvIUQCWUPGNYlKr0ca.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Mission Paradis (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/mVQeAwexqqUwEd2yPgLkYT7XVY9.jpg',
						'video': 'https://toma735.tomacloud.com/files/nJWq7dscdsqkODClYOpZuTNqHKRG6Q4uz0U.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Charlotte (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/hTLFNVxi2P5YeULAd5Mb2XbW9i4.jpg',
						'video': 'https://toma620.tomacloud.com/files/CtSn34X0btEDoD31pBPV7RqNW2d6BF2d9UB.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Pas moyen de s\'entendre ! (2022) ',
						'thumb': 'https://i.imgur.com/ooxYWTh.png',
						'video': 'https://toma621.tomacloud.com/files/apur2iC7gnghT9JfgChhRzXfY2wJdbJoBdQ.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'La Fille qui croyait aux miracles (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/qyD176B7Mpyc2w1GTnWrzfb1nnj.jpg',
						'video': 'https://toma320.tomacloud.com/files/4PXSKn1XyYFVKGG98pDBEHwfqvFIWBy0qvS.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Sous sa coupe (2022) ',
						'thumb': 'https://i.imgur.com/8J7KEIi.png',
						'video': 'https://toma320.tomacloud.com/files/nOsBhYnoMQbmarY3yQKOPNnbluFutDYQsrr.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Rebelles (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/7iMAzRhaw2OYbIFNlkeZ6CldMhA.jpg',
						'video': 'https://toma664.tomacloud.com/files/QWrzpAjxdlg11bpQKXPAUFoHqCgTSZ9JWBi.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'L\'horizon (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/l6lEBiRMPwwhCEE43LFpZFaufz7.jpg',
						'video': 'https://toma320.tomacloud.com/files/yf5JQZT8Ba093lwVZK9s0ppBxeBGqImZXrJ.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Les Racines du monde (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/wvgBnFTpKwcf4V2hWX0Vua0jKth.jpg',
						'video': 'https://toma522.tomacloud.com/files/3P1CGZA9p4GR187WEPxKiJHseCEHgo6ke8W.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'See You Soon (2019) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/bQAy1ruWLtyu6yw4XnX6K0aRccz.jpg',
						'video': 'https://toma664.tomacloud.com/files/JGizPwSDA7voz1ckEyyAodjDE0vzvncf3vO.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Samouraï Academy (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/6yD3h1jrTbnPvToXhGfOGFw53PV.jpg',
						'video': 'https://toma122.tomacloud.com/files/3fFnytFKoSinptdgaVJ8zlA3nwAG7phaFWy.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'On sourit pour la photo (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/qBJWTNFwa8vuyz9XvdDoJYJ0HuV.jpg',
						'video': 'https://toma187.tomacloud.com/files/9QoLOdbHR4AP7CkGOxAclenvg0LxG2GQT5C.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Nope (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/b1z84OMbtzmFWsiQWyonoPqWY2Z.jpg',
						'video': 'https://toma877.tomacloud.com/files/MzqlXmnnENpBhVPM3Yyxajzth4y7FL7slxO.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'À coeurs perdus (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/l2fcfdo1lO6YiJAoKuF7IV25i8P.jpg',
						'video': 'https://toma320.tomacloud.com/files/r1NqAPY5ZfnbndsZVH4K0y0gmnkYbYND0B4.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'The Disappointments Room (2016) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/4zHfitHwW1XDaJo9IF8LOsUbnif.jpg',
						'video': 'https://toma288.tomacloud.com/files/Cmaq6rzKiu6bVNaGOYMayeyjhHNXxvO9RZA.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Egō (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/hzC4yev1sW1GW4UvbqzPJ7JWZvc.jpg',
						'video': 'https://toma320.tomacloud.com/files/ylS5RIithkBWNkKEOOrsRAv6SgGu35KBqCH.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'En même temps (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/6kYy6wxCJaiYmiNU2UZSIV8Zixp.jpg',
						'video': 'https://toma620.tomacloud.com/files/Wc2hKz7uJVEa2Dm58gQNEPWGFZiLMdBIqD0.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'La Mif (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/8xAR06zA2ZcCpWentnWuWaLDIxB.jpg',
						'video': 'https://toma621.tomacloud.com/files/yEG5wjDfojsGOSIy0bUxiysQe39kBpP94we.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Le médecin imaginaire (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/6XX6OAT9SfYhZTei3QHl6NyHuTc.jpg',
						'video': 'https://toma655.tomacloud.com/files/UzzagLgLXlXrpnEvTiIQtXm4i954gHsah1k.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Me Time : Enfin seul ? (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/1pODNZAggj8fEkWaW2lIA4NAyMG.jpg',
						'video': 'https://toma620.tomacloud.com/files/8hY9tCD5OnmpS3ULWe7q0WOsU1cBLI1UZZ3.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'The Duke (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/u1rB2iR6Ib5TmCdSk0LbjmkEkqv.jpg',
						'video': 'https://toma621.tomacloud.com/files/PlS5jq1ijfVOHDsYoavt27jJEqF0hGP62Ic.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'I Came By (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/856bLLUvEYu3dRDXCCoRE7oxO0V.jpg',
						'video': 'https://toma664.tomacloud.com/files/lI9SGOQd0duelji74lP2Gl18fvOZkPlFxvy.mp4',
						'genre': 'Derniers Ajouts'},
						{'name': 'Top Gun : Maverick (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/uuwi4wwG6HAHVqaEvJDx6gI773N.jpg',
						'video': 'https://toma50.tomacloud.com/files/qlT9TDjjrCtvcZsfndrVir7TeXfCM9RduKn.mp4',
						'genre': 'Derniers Ajouts'},

                      ],
            'A l\'affiche': [{'name': 'Pinocchio (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/h32gl4a3QxQWNiNaR4Fc1uvLBkV.jpg',
						'video': 'https://toma468.tomacloud.com/files/yf2TccsNwFrqYAcY9SMTVIipkzvi8r7HHaB.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Thor : Love And Thunder (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/kSMarEm3ESOOr11dzsep2RZ1ClD.jpg',
						'video': 'https://toma902.tomacloud.com/files/cj9AuFqMDZkRU14OvIlKjR9VhcaXOFb0YkA.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Top Gun : Maverick (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/uuwi4wwG6HAHVqaEvJDx6gI773N.jpg',
						'video': 'https://toma50.tomacloud.com/files/qlT9TDjjrCtvcZsfndrVir7TeXfCM9RduKn.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Elvis (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/mTzwJL0ENwqIuMNGp2q6vkK3yis.jpg',
						'video': 'https://toma122.tomacloud.com/files/WA1jr2v3OIPbXngwvVaL4Z6Ik3Mf020XD2g.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Prey (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/8qlGO9zM1ysyw2xzsWfYMgnd2KT.jpg',
						'video': 'https://toma288.tomacloud.com/files/57D3oWAEuJe0fs2orxihDDC7a23zwWzB3cE.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Buzz l\'Éclair (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/5aM7y4Du4whbTCx4GafQXKj14xi.jpg',
						'video': 'https://toma761.tomacloud.com/files/izLVEvRCn1tSSFHC8sptDNJGy6I45oHnYsi.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Les Minions 2 : Il était une fois Gru (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/ucLdEGaIFlpIdGlkzYj2OcXbGhz.jpg',
						'video': 'https://toma761.tomacloud.com/files/IsRrwXQdkOGDrEOH00rf5QaMozSpCMake1M.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Jurassic World : Le Monde d\'après (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/4tRxeoxwf6X8l3yWYJr1CniKm6O.jpg',
						'video': 'https://toma57.tomacloud.com/files/G6zBsk8na0l9RDNktwZ05qxVz20ahNRXTrz.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Doctor Strange in the Multiverse of Madness (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/dbJDPJBHKxnMyvcc12mcbGK5RPF.jpg',
						'video': 'https://toma765.tomacloud.com/files/prrIoNQoypcqboc1nWUl0C6i1gLT9fWzHni.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Les Animaux Fantastiques : Les Secrets de Dumbledore (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/uXs7wMtsfnBFuGVogAxJXZXshFU.jpg',
						'video': 'https://toma664.tomacloud.com/files/N8O9aMYLZNRA9qzphtFYy6mYIeaWhAH4Ive.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Sonic 2, le film (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/7RSCL6V8BlekgVnNPok6tLW50tP.jpg',
						'video': 'https://toma735.tomacloud.com/files/KXcwLONenLAKUeCvnek6kylD3aPWX0gIXte.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Morbius (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/xBoIe0eX9UuSSPe5Qt6KXIQOd3I.jpg',
						'video': 'https://toma621.tomacloud.com/files/L2NIehJFZjIcCkmNYBF6JCYKzZrpNFDzHqi.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'The Northman (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/hk0JZyTHfgN35f43pJUhDPTNjM0.jpg',
						'video': 'https://toma621.tomacloud.com/files/rGQgWm8rmk7CIrh929xEmGEoyZAepiSQZJ6.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Ambulance (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/bvFeEZ10Gtt5Yd2KKDOTaO4m8v7.jpg',
						'video': 'https://toma28.tomacloud.com/files/F3b83fZeTZw9PjIhw0IZ4JWoFlcXJtTpx4y.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Uncharted (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/yd12LPRc6X7dZvSMo57xbXVGk3G.jpg',
						'video': 'https://toma621.tomacloud.com/files/Yw8jJlWwIeVeD0sVGhySu8VfgHJLraOqGWJ.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'The Batman (2022) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/8gVy5MLXtZBWghMykQtPMsNc5kH.jpg',
						'video': 'https://toma288.tomacloud.com/files/Kf0vorLiOWrpPB8Gok2IqHRi9DJnTtgDJg9.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Spider-Man: No Way Home (2021) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/j5f5bRlpChRuyHdexmeSnQmklDt.jpg',
						'video': 'https://toma288.tomacloud.com/files/a1FgDGJjBvYYbcA1BcIFgVGLkDYCZDVaEAr.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'The King’s Man - Première Mission (2021) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/tENLxofTH3ZiJyaqfVH37oQaFez.jpg',
						'video': 'https://toma664.tomacloud.com/files/t4yk9wUznbOvQ1QCP84pk9dWqTZivYyZ37j.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'House of Gucci (2021) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/cy6fvTf9YqehVhReYnm5cc3GqhZ.jpg',
						'video': 'https://toma51.tomacloud.com/files/MOcFDbueigLC8TzLQ1rIg3kjDGAnZUbMJnr.mp4',
						'genre': 'A l\'affiche'},
						{'name': 'Clifford (2021) ',
						'thumb': 'https://www.themoviedb.org/t/p/original/dtVB6o5ZUnyRTu3SsFqqcHdGbzU.jpg',
						'video': 'https://toma400.tomacloud.com/files/QCUuspxjzSiVSxu7IonRpIMVRKuvo8JeKEJ.mp4',
						'genre': 'A l\'affiche'},

                     ]}


def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or API.

    .. note:: Consider using `generator functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :return: The list of video categories
    :rtype: types.GeneratorType
    """
    return VIDEOS.keys()


def get_videos(category):
    """
    Get the list of videofiles/streams.

    Here you can insert some parsing code that retrieves
    the list of video streams in the given category from some site or API.

    .. note:: Consider using `generators functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :param category: Category name
    :type category: str
    :return: the list of videos in the category
    :rtype: list
    """
    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, 'My Video Collection')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
                          'icon': VIDEOS[category][0]['thumb'],
                          'fanart': VIDEOS[category][0]['thumb']})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': category,
                                    'genre': category,
                                    'mediatype': 'video'})
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': video['name'],
                                    'genre': video['genre'],
                                    'mediatype': 'video'})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
